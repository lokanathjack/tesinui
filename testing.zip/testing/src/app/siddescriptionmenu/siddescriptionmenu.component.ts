import { Component, OnInit, Injectable, Input } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Http, Response } from '@angular/http';
import { HttpClient } from '@angular/common/http'
import { Observable } from "rxjs";
import { map } from "rxjs/operators";
import {ActivatedRoute, Router} from "@angular/router";
import { SidDescMenu } from '../model/commonSidData.model';

@Component({
  selector: 'app-siddescriptionmenu',
  templateUrl: './siddescriptionmenu.component.html',
  styleUrls: ['./siddescriptionmenu.component.css']
})
export class SiddescriptionmenuComponent implements OnInit {

  //apiRoot: string = 'http://zlt17369.vci.att.com:30043/restservices/helloworld/v1/service/getSIDID';
  //valueStr: string;
  //public sidtype: string;
  public requesttype: string;
  public sidID : string;
  public sidRestriction : String;
  @Input() sidtype: string;
  
  
  constructor(private http:Http, private router: Router,private route: ActivatedRoute,private sidDescMenu: SidDescMenu) { 
   // this.route.queryParams.subscribe(params => {
  //    this.sidtype = params["commSidType"];
   //   this.requesttype = params["commRequestType"];
  //});
  
  this.sidtype=sidDescMenu.getSidType();
  this.requesttype=sidDescMenu.getRequestType();
  
  this.sidID=sidDescMenu.getSidId();
  //console.log(this.sidtype);
  //console.log(this.requesttype);
  }


  ngOnInit() {
    //this.router.navigate(["narrative"]);
    //this.search('Moo');
    //alert(this.sidDescMenu.getSidId());
    this.sidtype=this.sidDescMenu.getSidType();
  this.requesttype=this.sidDescMenu.getRequestType();
  
  this.sidID=this.sidDescMenu.getSidId();
  
  }
}
