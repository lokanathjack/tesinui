import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HttpClientJsonpModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { RouterModule, Routes, NavigationExtras, Router} from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {HttpModule} from "@angular/http";
import { MytaskComponent } from './mytask/mytask.component';
import { UbmapplicationComponent } from './ubmapplication/ubmapplication.component';
import { UbmmainuiComponent } from './ubmmainui/ubmmainui.component';
import { NarrativeComponent } from './narrative/narrative.component';
import { ApprovalComponent } from './approval/approval.component';
import { SiddescriptionmenuComponent } from './siddescriptionmenu/siddescriptionmenu.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SidDescMenu } from './model/commonSidData.model';
//import { userservice } from './service/user.service';


const appRoutes: Routes = [
{
path: 'app-root',
component: AppComponent
},
 {
path: 'mytasks',
component: MytaskComponent
},
 {
path: 'ubmapplication',
component: UbmapplicationComponent
},
 {
path: 'ubmmainui',
component: UbmmainuiComponent
},
{
  path: 'siddescriptionmenu',
  component: SiddescriptionmenuComponent
  },
 {
path: 'narrative',
component: NarrativeComponent
},
{
  path: 'approval',
  component: ApprovalComponent
  }
  
];
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    MytaskComponent,
    UbmapplicationComponent,
    UbmmainuiComponent,
    NarrativeComponent,
    ApprovalComponent,
    SiddescriptionmenuComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(appRoutes),
    BrowserAnimationsModule,
    HttpModule,
    HttpClientModule,
    HttpClientJsonpModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports: [RouterModule],
  providers: [SidDescMenu],
  bootstrap: [AppComponent]
})
export class AppModule { 
  
}
