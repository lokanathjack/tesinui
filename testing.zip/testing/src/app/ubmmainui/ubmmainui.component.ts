import { Component, OnInit } from '@angular/core';
import {Router,RouterModule, NavigationExtras, Routes} from "@angular/router";
import { FormGroup, FormControl } from '@angular/forms';
import { ModuleWithProviders } from "@angular/core";
import { SidDescMenu } from '../model/commonSidData.model';
import { Http } from '@angular/http';

@Component({
  selector: 'app-ubmmainui',
  templateUrl: './ubmmainui.component.html',
  styleUrls: ['./ubmmainui.component.css']
})
export class UbmmainuiComponent implements OnInit {

  public constructor(private http:Http,private router: Router,private sidDescMenu: SidDescMenu) { }
  //const routes: Routes = [];
  apiRoot: string = 'http://zlt17365.vci.att.com:31869/restservices/helloworld/v1/service/getSIDID';
  valueStr: string;
 commSidType='';
 commRequestType='';
 commSidRestriction='';
  formdata;
  ngOnInit() {
    this.formdata = new FormGroup({
      commSidType: new FormControl(''),
      commRequestType: new FormControl(''),
      commSidRestriction: new FormControl('')
      });
      this.search('Moo');
  }

  search(term: string) {
    let promise = new Promise((resolve, reject) => {
      let apiURL = `${this.apiRoot}`;
      //let apiURL = `http://zlt17363.vci.att.com:30157/restservices/helloworld/v1/service/getSIDID`;
      //let apiURL=`${this.apiRoot}`;
      this.http.get(apiURL)
        .toPromise()
        .then(
          res => { // Success
            this.valueStr = res.json();
            console.log(this.valueStr);
            this.sidDescMenu.setSidId(this.valueStr);
            console.log(this.sidDescMenu.getSidId());
          },
          msg => { // Error
            reject(msg);
          }
        );
    });
    return promise;
  }
  
  public onSubmit(data) {
    //let navigationExtras: NavigationExtras = {
   //   queryParams: {
   //       "commSidType": data.commSidType,
   //       "commRequestType": data.commRequestType
    //  }
    this.sidDescMenu.setSidType(data.commSidType);
    this.sidDescMenu.setRequestType(data.commRequestType);
    this.sidDescMenu.setSidRestriction(data.commSidRestriction);
    
  //};
  //console.log(navigationExtras.queryParams);
  //this.router.navigate(["narrative"], navigationExtras);
  this.router.navigate(["narrative"]);
  //siddescriptionmenu
  }

}
