import { Injectable } from '@angular/core';
// Import HttpClient class
import { HttpClient } from '@angular/common/http';

@Injectable()
export class serservice {
  constructor(private http: HttpClient) { }
getData() {
    const url = 'http://zlt17363.vci.att.com:30157/restservices/helloworld/v1/service/getSIDID';

    // Pass the key for your callback (in this case 'callback')
    // as the second argument to the jsonp method
    return this.http.jsonp(url, 'JSONP_CALLBACK');
  }
}