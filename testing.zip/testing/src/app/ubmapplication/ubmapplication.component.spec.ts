import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UbmapplicationComponent } from './ubmapplication.component';

describe('UbmapplicationComponent', () => {
  let component: UbmapplicationComponent;
  let fixture: ComponentFixture<UbmapplicationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UbmapplicationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UbmapplicationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
