import { Component, OnInit, Injectable } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Http, Response } from '@angular/http';
import { HttpClient } from '@angular/common/http'
import { Observable } from "rxjs";
import { map } from "rxjs/operators";
import {ActivatedRoute} from "@angular/router";
import { SidDescMenu } from '../model/commonSidData.model';
import { Namevaluepair } from '../model/namevaluepair.model';

@Component({
  selector: 'app-narrative',
  templateUrl: './narrative.component.html',
  styleUrls: ['./narrative.component.css']
})

export class NarrativeComponent implements OnInit {
  narrative: FormGroup;
  //apiRoot: string = 'http://zlt17363.vci.att.com:32214/restservices/helloworld/v1/service/getSIDID';
  keys: String[];
  valueStr: string;
  valueStrWebPhone = [];
  valueStrGroup = [];
  valueFinanceApprover =[];
  mouseOver =[];
  //valuMarkets : Namevaluepair[];
  valuMarkets : [];
  valueRequiredCoreAppover = [];
  valueProductAppover = [];
  valueChannelAppover = [];
  valueAlternateAppover =[];

//valuMarkets =[];
  public requesttype: string;
  public sidID : string;
  public sidRestriction : String;
  names: any;
  selectedAll: any;
  selectedNames: any;
  
  constructor(private http:Http, private route: ActivatedRoute,private sidDescMenu: SidDescMenu) { 
    this.sidRestriction =sidDescMenu.getSidRestriction();
  }

  public onChange(event): void {  // event will give you full breif of action
    const newVal = event.target.value;
    //alert(newVal);
    //console.log(newVal);
    this.webphone(newVal);
  }

  selectAll() {
    this.selectedAll = !this.selectedAll;

    for (var i = 0; i < this.names.length; i++) {
        this.names[i].selected = this.selectedAll;
    } 
}
checkIfAllSelected() {
  var totalSelected =  0;
  for (var i = 0; i < this.names.length; i++) {
        if(this.names[i].selected) totalSelected++;
    } 
this.selectedAll = totalSelected === this.names.length;

return true;
}


  ngOnInit() {
    this.narrative = new FormGroup({
      commSidDescription: new FormControl("Name is required", [Validators.required]),
    });
    
    this.sidID=this.sidDescMenu.getSidId();
    this.requesttype=this.sidDescMenu.getRequestType();
    this.sidRestriction=this.sidDescMenu.getSidRestriction();
    this.searchMouseOver('Moo');
    this.searchGroup('Moo');
    this.searchGroupFinance('Moo');
    this.markets(this.requesttype,this.sidID,'NARRATIVE');
    this.requiredCoreApprovers();
    this.coreApproval();
  }
  requiredCoreApprovers() {
    let promise = new Promise((resolve, reject) => {
      //let apiURL = `${this.apiRoot}`;
      let apiURL = `http://zltv6463.vci.att.com:32574/restservices/helloworld/v1/service/getAllGroupMembers?groupName=CoreApprovers`;
      //let apiURL=`${this.apiRoot}`;
      this.http.get(apiURL)
        .toPromise()
        .then(
          res => { // Success
           //console.log(res.json());
           this.valueRequiredCoreAppover = res.json();
          },
          msg => { // Error
            reject(msg);
          }
        );
    });
    return promise;
  }
  searchMouseOver(term: string) {
    let promise = new Promise((resolve, reject) => {
      //let apiURL = `${this.apiRoot}`;
      let apiURL = `http://zltv6463.vci.att.com:30837/restservices/helloworld/v1/service/getMouseOverText?screenName=Narrative`;
      //let apiURL=`${this.apiRoot}`;
      this.http.get(apiURL)
        .toPromise()
        .then(
          res => { // Success
           //console.log(res.json());
           this.mouseOver = res.json();
           //console.log(this.mouseOver);
           /*this.mouseOver.forEach((value: string, key: string) => {
            console.log(key, value);
        });*/
          },
          msg => { // Error
            reject(msg);
          }
        );
    });
    return promise;
  }
  searchGroupFinance(term: string) {
    let promise = new Promise((resolve, reject) => {
      //let apiURL = `${this.apiRoot}`;
      let apiURL = `http://zlt17369.vci.att.com:30043/restservices/helloworld/v1/service/getAllGroupMembers?groupName=Finance%20Approver`;
      //let apiURL=`${this.apiRoot}`;
      this.http.get(apiURL)
        .toPromise()
        .then(
          res => { // Success
           //console.log(res.json());
           this.valueFinanceApprover = res.json();
          },
          msg => { // Error
            reject(msg);
          }
        );
    });
    return promise;
  }
  searchGroup(term: string) {
    let promise = new Promise((resolve, reject) => {
      //let apiURL = `${this.apiRoot}`;
      let apiURL = `http://zlt17369.vci.att.com:30043/restservices/helloworld/v1/service/getAllGroupMembers?groupName=Requestor`;
      //let apiURL=`${this.apiRoot}`;
      this.http.get(apiURL)
        .toPromise()
        .then(
          res => { // Success
           // console.log(res.find(groupName ==='Requestor'));
           //console.log(res.json());
           this.valueStrGroup = res.json();
            //this.keyValuePairsModel = res.json().keyValuePairsModel;
            //alert(this.keyValuePairsModel.length);
            //this.groupUsers = res.json();
            //this.mapUsers(this.groupUsers);
            
            //this.valueStrGroup = res.json();
            //console.log(this.valueStrGroup.find(res => res.groupName=='Requestor' && res.keyValuePairsModel));
          },
          msg => { // Error
            reject(msg);
          }
        );
    });
    return promise;
  }
  /*mapUsers(groupUsers) {
    // Map the getContacts response to a Contact[]
    for ( let group of groupUsers ) {
     alert(group.groupName);
     for(let user of group.keyValuePairsModel){alert(user.firstName);
      this.users.push(new User(user.firstName,user.lastName,user.attuid));
    }
    }

    console.log(this.users);
  }*/
  
  webphone(term: string) {
    let promise = new Promise((resolve, reject) => {
      //let apiURL = `${this.apiRoot}`;
      //alert(term);
      let apiURL = `http://zlt17365.vci.att.com:31869/restservices/helloworld/v1/service/requestor?attuid=`;
      //let apiURL=`${this.apiRoot}`;
      this.http.get(apiURL+term)
        .toPromise()
        .then(
          res => { // Success
            //console.log(res.json());
            this.valueStrWebPhone = res.json();
          },
          msg => { // Error
            reject(msg);
          }
        );
    });
    return promise;
  }
  
  markets(sidtype: string,sidid: string,screenname: string) {
    let promise = new Promise((resolve, reject) => {
      //let apiURL = `${this.apiRoot}`;
      //alert(term);
      screenname='NARRATIVE';
      let apiURL = `http://hvdivd18caf8092:9081/restservices/helloworld/v1/service/getConfigDetails?sidType=`;
      let apiURL1 = `http://hvdivd18caf8092:9081/restservices/helloworld/v1/service/getConfigDetails?sidType=QUICK%20UPDATE&pageName=NARRATIVE&sidId=20181002001`;
      //let apiURL=`${this.apiRoot}`;
      //this.http.get(apiURL+sidtype+'&pageName='+screenname+'&sidId='+sidid)
      this.http.get(apiURL1)
        .toPromise()
        .then(
          res => { // Success
            //console.log(res.find(CHANNEL ==='Requestor'));
            //console.log(res.find);
            //console.log(res.find(res => res.sidType));
            //this.valuMarkets = res.json();
            //console.log(this.valuMarkets.find(res => res.sidType));
             this.valuMarkets = JSON.parse(res.json()["MARKETS"]);
             //console.log("actual:"+this.valuMarkets);
                         
             /*let item :Namevaluepair;
              for (var i in this.valuMarkets) {
                item = this.valuMarkets[i];
                  console.log('-'+item.name);
              }                 */
            //console.log(channel);
           /* let keyArr: any[] = Object.keys(res.json().CHANNEL);
            console.log(keyArr);
                   keyArr.forEach((key: any) => {
                      console.log(key[0].name);
                     //this.valuMarkets.push(res.json().CHANNEL[key]);
                     console.log(key['name']);
                   });*/
          },
          msg => { // Error
            reject(msg);
          }
        );
    });
    return promise;
  }

  coreApproval() {
    let promise = new Promise((resolve, reject) => {
      let apiURL = `http://hvdivd00alh0653:9081/restservices/helloworld/v1/service/getApproverOptions?approverType=QUICKUPDATE`;
      this.http.get(apiURL)
        .toPromise()
        .then(
          res => { 
            this.valueProductAppover = (res.json()["product"]);
             this.valueChannelAppover = (res.json()["channel"]);
             this.valueAlternateAppover = (res.json()["alternate"]);
             console.log("actual:"+this.valueAlternateAppover);

          },
          msg => { // Error
            reject(msg);
          }
        );
    });
    return promise;
  }

}


