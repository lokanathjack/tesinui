import { Component } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ubmangularUI';
  public constructor(private router: Router) { }
  
  /*commSidType='';
 commRequestType='';
 commSidRestriction='';
  formdata;
  ngOnInit() {
    this.formdata = new FormGroup({
      commSidType: new FormControl(''),
      commRequestType: new FormControl(''),
      commSidRestriction: new FormControl('')
      });
  }*/
  
}
